<?xml version="1.0"?>
<xsl:stylesheet xmlns:xsl="uri:xsl">

	<xsl:template match="/">

		<html>
		
		<head>
			<title>Historical Alarm File Data</title>
			<META HTTP-EQUIV="Refresh" CONTENT="60" />
		</head>
		
		<body bgcolor="#ffffff" text="#000000" link="#00FF00" vlink="#00FF00" alink="#0000FF">
	
		<center><h2><i>Historical Alarm Data</i></h2></center>
		
		<p/>
		<table border="2" cellspacing="1" cellpadding="2" width="100%">
		<tr>
			<xsl:for-each select="AlarmFile/AlarmLegend/field"> 
			<xsl:if test="@Mnemonic[.!='HTS' and .!='TS' and .!='A'
			    and .!='T' and .!='L' and .!='D']">
			    <td  bgcolor="#f0ffff">
			    <h3><xsl:value-of select="@Name"/></h3>
			    </td>
			</xsl:if>
			</xsl:for-each> 

		</tr>

		<xsl:for-each select="AlarmFile/AlarmRecord"> 
			<tr>
			    <td><xsl:value-of select="@DT"/></td>
			    <td><xsl:value-of select="@TM"/></td>
			    <td><xsl:value-of select="@AF"/></td>
			    <td><xsl:value-of select="@TF"/></td>
			    <td><xsl:value-of select="@LF"/></td>
			    <td><xsl:value-of select="@P"/></td>
			    <td><xsl:value-of select="@DF"/></td>
			    <td><xsl:value-of select="@V"/></td>				    
			   <td>
				<xsl:if test="@LM[.!='']"> 
					<xsl:value-of select="@LM"/> 
				</xsl:if>
				<xsl:if test="@LM[.='']"> 
					&#160;
				</xsl:if>	
			   </td>
			   <td><xsl:value-of select="@N"/></td>
			   <td><xsl:value-of select="@G"/></td>
			   <td>
				<xsl:if test="@O[.!='']"> 
					<xsl:value-of select="@O"/> 
				</xsl:if>
				<xsl:if test="@O[.='']"> 
					&#160;
				</xsl:if>
			   </td>
			   <td>
				<xsl:if test="@C[.!='']"> 
					<xsl:value-of select="@C"/> 
				</xsl:if>
				<xsl:if test="@C[.='']"> 
					&#160;
				</xsl:if>
			   </td>
			   <td>
				<xsl:if test="@MSG[.!='']"> 
					<xsl:value-of select="@MSG"/> 
				</xsl:if>
				<xsl:if test="@MSG[.='']"> 
					&#160;
				</xsl:if>
			   </td>
			</tr>
		</xsl:for-each> 
		</table>
	
	   </body>
	
	   </html>

	</xsl:template>
</xsl:stylesheet>

